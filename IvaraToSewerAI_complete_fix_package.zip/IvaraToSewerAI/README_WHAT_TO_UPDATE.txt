Files updated in this package:

1. SOA/BPEL/SendWOTChanges.bpel
   - keeps your existing STG1 update
   - adds a new direct parent status update to CUSTOMERDATA.EPSEWERAI_WOT_STG
   - parent row now gets vWOTFeedStatus directly after project outcome is known

2. SOA/composite.xml
   - imports and wires the new UpdateWOTParentStatus DB adapter

3. SOA/Adapters/UpdateWOTParentStatus_db.jca
4. SOA/Adapters/UpdateWOTParentStatus-or-mappings.xml
5. SOA/Adapters/UpdateWOTParentStatus-properties.xml
6. SOA/WSDLs/UpdateWOTParentStatus.wsdl
7. SOA/Schemas/UpdateWOTParentStatus_table.xsd
   - new DB adapter artifacts for direct update of CUSTOMERDATA.EPSEWERAI_WOT_STG

8. SQL_TRG_STG1_SENT_SYNC_UPDATED.sql
   - optional trigger update
   - useful for legacy STG1 -> STG propagation and cleanup
   - direct parent update in BPEL is now the main fix for project ERROR/SENT

Recommended deployment order:
1) compile trigger SQL
2) replace the SOA files above in your project
3) open the project in JDeveloper
4) confirm UpdateWOTParentStatus appears as a DB adapter reference
5) deploy composite
6) test bad API key -> EPSEWERAI_WOT_STG.FEED_STATUS should become ERROR
7) test good API key -> EPSEWERAI_WOT_STG.FEED_STATUS should become SENT
